package com.example.dicodsub2.Activity

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.bumptech.glide.Glide
import com.example.dicodsub2.Model.User
import com.example.dicodsub2.R
import com.example.dicodsub2.SectionsPagerAdapter
import kotlinx.android.synthetic.main.activity_detail.*
import kotlinx.android.synthetic.main.row_user_main.view.*

class DetailActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detail)

        val data = intent.getParcelableExtra<User>("data")

        tv_name_detail_user.text = data.name
        tv_compony_detail_user.text = data.compony
        tv_follower_detail_user.text = data.follower.toString()+" Followers"
        tv_following_detail_user.text = data.following.toString()+" Followings"
        tv_repo_detail_user.text = data.repository.toString()+" Repository"
        if(data.avatar != null){
            Glide.with(this)
                .load(data.avatar)
                .fitCenter()
                .centerCrop()
                .into(img_photo_detail_user);
        }

        val mFollowerFragment = FollowerFragment()
        val mBundle = Bundle()
        mBundle.putString(FollowerFragment.EXTRA_USERAME, data.username)
        mFollowerFragment.arguments = mBundle


        val sectionsPagerAdapter = SectionsPagerAdapter(this, supportFragmentManager)
        view_pager.adapter = sectionsPagerAdapter
        tabs.setupWithViewPager(view_pager)
        supportActionBar?.elevation = 0f
    }
}
