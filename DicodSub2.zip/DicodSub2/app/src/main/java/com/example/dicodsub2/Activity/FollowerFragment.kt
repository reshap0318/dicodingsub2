package com.example.dicodsub2.Activity


import android.content.Intent
import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.dicodsub2.Adapter.followerAdapter
import com.example.dicodsub2.Adapter.userAdapter
import com.example.dicodsub2.Api.apiBuilder
import com.example.dicodsub2.Api.userApi
import com.example.dicodsub2.Model.User

import com.example.dicodsub2.R
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.fragment_follower.*
import okhttp3.ResponseBody
import org.json.JSONObject
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response


class FollowerFragment : Fragment() {

    companion object {
        var EXTRA_USERAME = "USERNAME"
    }

    val displayList = ArrayList<User>()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_follower, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        Toast.makeText(activity, "oke", Toast.LENGTH_SHORT)

        if (arguments != null) {
            val username = arguments?.getString(EXTRA_USERAME)

            val apiBuilder = apiBuilder.buildService(userApi::class.java)
            val requestSearch = username?.let { apiBuilder.followerUser(it) }

            if (requestSearch != null) {
                requestSearch.enqueue(object: Callback<ResponseBody> {

                    override fun onResponse(call: Call<ResponseBody>, response: Response<ResponseBody>) {
                        if(response.isSuccessful()){
                            try {
                                val result = response.body()?.string()
                                val responseObject = JSONObject(result)
                                val items = responseObject.getJSONArray("items");
                                for (i in 0 until items.length()) {
                                    val jsonObject = items.getJSONObject(i)
                                    val username = jsonObject.getString("login")
                                    requestDetailUser(username)
                                }


                            } catch (e: Exception) {
                                Toast.makeText(activity, e.message, Toast.LENGTH_SHORT).show()
                                e.printStackTrace()
                            }
                        }else{
                            Toast.makeText(activity, "Gagal Load Data", Toast.LENGTH_SHORT).show()
                        }
                    }

                    override fun onFailure(call: Call<ResponseBody>, t: Throwable) {
                        Log.e("debug", "onFailure: ERROR > " + t.toString());
                    }

                })
            }

            val layoutManager = LinearLayoutManager(activity)
            val userAdapter = followerAdapter{ user ->
                val intent = Intent(activity, DetailActivity::class.java)
                intent.putExtra("data",user)
                startActivity(intent)
            }
            var rv_list_user_follower: RecyclerView = view.findViewById(R.id.rv_list_user_follower)

            rv_list_user_follower.adapter = userAdapter
            rv_list_user_follower.layoutManager = layoutManager
            userAdapter.datas = displayList
        }

    }

    private fun requestDetailUser(username: String){
        val apiBuilder = apiBuilder.buildService(userApi::class.java)
        val requestDetail = apiBuilder.detailUser(username)
        requestDetail.enqueue(object: Callback<ResponseBody>{
            override fun onResponse(call: Call<ResponseBody>, response: Response<ResponseBody>) {
                if(response.isSuccessful()){
                    try {
                        val result = response.body()?.string()
                        val responseObject = JSONObject(result)
                        val username =  responseObject.getString("login")
                        val name = responseObject.getString("name")
                        val avatar = responseObject.getString("avatar_url")
                        val compony = responseObject.getString("company")
                        val location = responseObject.getString("location")
                        val repo = responseObject.getInt("public_repos")
                        val follower = responseObject.getInt("followers")
                        val following = responseObject.getInt("following")
                        displayList.add(User(
                            username,
                            name,
                            avatar,
                            compony,
                            location,
                            repo,
                            follower,
                            following
                        ))
                    } catch (e: Exception) {
                        Toast.makeText(activity, e.message, Toast.LENGTH_SHORT).show()
                        e.printStackTrace()
                    }
                }else{
                    Toast.makeText(activity, "Gagal Load Data", Toast.LENGTH_SHORT).show()
                }
            }

            override fun onFailure(call: Call<ResponseBody>, t: Throwable) {
                Log.e("debug", "onFailure: ERROR > " + t.toString());
            }
        })
    }


}
